Full examples apps built with Firecrawl can be found at this repo: https://github.com/mendableai/firecrawl-app-examples
