---
template: home.html
title: Material for MkDocs
social:
  cards_layout_options:
    title: Documentation that simply works
---

Welcome to Material for MkDocs.
