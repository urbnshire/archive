# Slack

Copy and paste the following into Slack's import theme input.

Light:
`#f2f0e5,#121016,#343331,#fffcf0,#575653,#100f0f,#24837b,#a02f6f,#f2f0e5,#100f0f`

Dark:
`#343331,#121016,#cecdc3,#100f0f,#575653,#fffcf0,#24837b,#a02f6f,#282726,#fffcf0`
