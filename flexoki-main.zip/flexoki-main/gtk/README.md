# USAGE  
Put these files in `~/.local/share/themes/flexoki` if the folder do not exist, create it.
