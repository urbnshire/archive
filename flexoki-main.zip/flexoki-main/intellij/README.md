# Flexoki for IntelliJ and Jetbrains IDEs

## Flexoki Dark

![Flexoki Dark](screenshots/flexoki-intellij-dark.png)

![Flexoki Dark](screenshots/flexoki-intellij-dark-2.png)

## Flexoki Light

![Flexoki Light](screenshots/flexoki-intellij-light.png)

![Flexoki Light](screenshots/flexoki-intellij-light-2.png)

## How to install:

1. Press `Ctl` `Alt` `S` to open the IDE settings and then select **Editor | Color Scheme**.
2. From the #Scheme# list, select a color scheme, then click the cog icon, the click **Import Scheme**.

