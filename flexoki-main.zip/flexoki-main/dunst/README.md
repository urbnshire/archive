# Usage
1. Copy the contents of selected theme into your dunst config file(usually `~/.config/dunst/dunstrc`)
2. Restart dunst
