# Usage
Put two files in `~/.config/wal/colorschemes/`  

```
wal --theme ~/.config/wal/colorschemes/light/flexoki-light.json
wal --theme ~/.config/wal/colorschemes/dark/flexoki-dark.json
```
