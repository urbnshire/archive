# Usage
1. Copy selected mode into your imv's config(usually `~/.config/imv/config`)
2. Enjoy!
