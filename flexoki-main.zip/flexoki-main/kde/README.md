# USAGE
Open KDE System Settings -> Appearance -> Colors -> Install from files... -> choose the provided `.color` files
