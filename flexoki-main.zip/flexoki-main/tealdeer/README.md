# Usage
1. Locate your `Config path`:
```sh
tldr --show-paths
```
2. Paste the contents of either `flexoki-dark.toml` or `flexoki-light.toml` into your config
